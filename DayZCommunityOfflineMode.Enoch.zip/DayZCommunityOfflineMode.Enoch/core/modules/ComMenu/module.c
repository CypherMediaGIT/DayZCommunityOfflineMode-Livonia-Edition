/*
    Define used for optional compilations
*/
#define MODULE_COM_MENU

/*
    Include of all .c files that belong to this module
*/
#include "$CurrentDir:missions\\DayZCommunityOfflineMode.Enoch\\core\\modules\\ComMenu\\gui\\WelcomeMenu.c"