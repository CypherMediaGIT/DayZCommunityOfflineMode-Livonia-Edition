class SceneSaveST 
{
	// temporary class
	string name;
	ref array<ref Param3<string, vector, vector>> m_SceneObjects = new ref array< ref Param3<string, vector, vector>>;
} 